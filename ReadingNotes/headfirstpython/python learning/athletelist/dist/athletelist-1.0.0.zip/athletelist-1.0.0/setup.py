# -*- coding: utf-8 -*-
"""
Created on Mon Mar 27 15:35:38 2017

@author: River
"""
from distutils.core import setup

setup(
      name='athletelist',
      version='1.0.0',
      py_modules=['athletelist'],
      author='WangLiuying',
      author_email='13656036646@163.com',
      url="github.org/WangLiuying",
      description='self-define class AthleteList',
      )
        