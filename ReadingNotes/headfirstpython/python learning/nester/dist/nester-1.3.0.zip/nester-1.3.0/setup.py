# -*- coding: utf-8 -*-
"""
Created on Mon Mar 27 15:35:38 2017

@author: River
"""
from distutils.core import setup

setup(
      name='nester',
      version='1.3.0',
      py_modules=['nester'],
      author='WangLiuying',
      author_email='13656036646@163.com',
      url="github.org/WangLiuying",
      description='a simple printer of nested lists',
      )
        