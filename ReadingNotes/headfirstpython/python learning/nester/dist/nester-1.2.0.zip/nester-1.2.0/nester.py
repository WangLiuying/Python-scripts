# -*- coding: utf-8 -*-
"""
Created on Thu Mar  9 11:44:04 2017

@author: River
"""

"""a function for printing all the movies' names even if it is in a list of list"""
def print_lol(the_list,level=0):
    for each_item in the_list:
        if isinstance(each_item,list):
            print_lol(each_item,level+1)
        else:
            for tab_stop in range(level):
                print("\t",end="")
            print(each_item)

"""This is the standard way to include a multiple-line comment in your code"""